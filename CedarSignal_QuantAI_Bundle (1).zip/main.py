# Launch script for CedarSignal
print('Launching CedarSignal UI...')